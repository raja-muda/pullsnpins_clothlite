---
name: Feature request
about: Suggest an idea for ClothLite
title: ''
labels: feature_request
assignees: ''

---

**Describe the feature you'd like to see**
A clear and concise description of what you would like ClothLite to do.

**Why do you need it?**
What problem does it solve in your workflow?

**Comparisons**
Is there a tool or add-on that already does this? Link to it so we can take a look.
