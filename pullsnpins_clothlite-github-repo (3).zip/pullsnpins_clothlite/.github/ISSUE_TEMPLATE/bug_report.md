---
name: Bug report
about: Report something that does not work as expected
title: 'Bug: '
labels: bug
assignees: ''

---

**Bug description**
A clear and concise description of what went wrong. Screenshots or a short video help a lot.

**How to reproduce**
1. __
2. __
3. __

**Cloth setup (if relevant)**
- Mesh type and vertex count: __
- Did the mesh already have shape keys or a pin group? __
- Was the cloth cache baked? __

**Versions used**
- Blender version: __
- ClothLite version: __
- Operating system: __

**Console output**
If Blender printed errors in the system console, paste them here.
